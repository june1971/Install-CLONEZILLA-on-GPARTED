The file fail-mbr.txt was created by Orgad Shaneh.
It will be converted to binary format using:
xxd -r fail-mbr.txt > fail-mbr.bin
For more info, please check:
https://sourceforge.net/p/clonezilla/feature-requests/19/

The icon file lxrandr.xpm was taken from gnome-desktop-data (/usr/share/pixmaps/monitor.png)
The icon file netcfg.xpm was taken from gnome-control-center (/usr/share/pixmaps/control-center2.xpm)
All credits go to those developers.
